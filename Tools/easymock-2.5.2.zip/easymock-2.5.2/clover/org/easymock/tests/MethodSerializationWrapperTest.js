var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":39,"id":4161,"methods":[{"el":37,"sc":5,"sl":32}],"name":"MethodSerializationWrapperTest","sl":25},{"el":30,"id":4161,"methods":[{"el":29,"sc":9,"sl":28}],"name":"MethodSerializationWrapperTest.A","sl":27}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_566":{"methods":[{"sl":32}],"name":"testGetMethod","pass":true,"statements":[{"sl":34},{"sl":35},{"sl":36}]},"test_956":{"methods":[{"sl":32}],"name":"testGetMethod","pass":true,"statements":[{"sl":34},{"sl":35},{"sl":36}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [566, 956], [], [566, 956], [566, 956], [566, 956], [], [], []]
