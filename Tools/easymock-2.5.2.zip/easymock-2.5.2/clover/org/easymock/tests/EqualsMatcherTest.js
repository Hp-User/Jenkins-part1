var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":44,"id":4055,"methods":[{"el":38,"sc":5,"sl":28},{"el":43,"sc":5,"sl":40}],"name":"EqualsMatcherTest","sl":25}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_499":{"methods":[{"sl":28}],"name":"equalsMatcher","pass":true,"statements":[{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":37}]},"test_638":{"methods":[{"sl":40}],"name":"differentNumberOfArguments","pass":true,"statements":[{"sl":42}]},"test_963":{"methods":[{"sl":40}],"name":"differentNumberOfArguments","pass":true,"statements":[{"sl":42}]},"test_997":{"methods":[{"sl":28}],"name":"equalsMatcher","pass":true,"statements":[{"sl":30},{"sl":31},{"sl":32},{"sl":33},{"sl":34},{"sl":35},{"sl":37}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [499, 997], [], [499, 997], [499, 997], [499, 997], [499, 997], [499, 997], [499, 997], [], [499, 997], [], [], [963, 638], [], [963, 638], [], []]
